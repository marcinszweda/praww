package mod04.ex3;

public class TestStack2 {

	public static void main(String[] args) {
		Stack<String> s = new Stack<String>();
		Pusher pusher1 = new Pusher(s, 500);
		Pusher pusher2 = new Pusher(s, 500);
		Popper popper = new Popper(s, 999);
		Thread t1 = new Thread(pusher1, "pusher1");
		Thread t2 = new Thread(pusher2, "pusher2");
		Thread t3 = new Thread(popper, "popper");
		t3.start();
		t2.start();
		t1.start();
		while (t1.isAlive() || t2.isAlive() || t3.isAlive()) {
		}
		System.out.println("Empty stack? " + s.isEmpty());
		System.out.println("Popping 1 element...");
		s.pop();
		System.out.println("Empty stack? " + s.isEmpty());
	}
}