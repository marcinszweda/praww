package mod04.ex3;

import java.util.EmptyStackException;
import java.util.Random;

public class Popper implements Runnable {
	private Stack<String> stack;
	private int repeats;

	public Popper(Stack<String> stack, int repeats) {
		this.stack = stack;
		this.repeats = repeats;
	}

	@Override
	public void run() {
		Random r = new Random();
		int fails = 0;
		boolean popped;
		System.out.println("'" + Thread.currentThread().getName()
				+ "' is going to get " + repeats + " elements from the stack");
		for (int i = 0; i < repeats; i++) {
			do {
				try {
					stack.pop();
					popped = true;
				} catch (EmptyStackException e) {
					fails++;
					popped = false;
				}
			} while (!popped);
			try {
				Thread.sleep(r.nextInt(10));
			} catch (InterruptedException e) {
				return;
			}
		}
		System.out.println("'" + Thread.currentThread().getName() + "' found "
				+ fails + " times empty stack");
	}
}