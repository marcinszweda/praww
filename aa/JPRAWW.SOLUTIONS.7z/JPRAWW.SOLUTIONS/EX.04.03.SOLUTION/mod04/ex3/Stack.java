package mod04.ex3;

import java.util.EmptyStackException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import static java.util.concurrent.atomic.AtomicReferenceFieldUpdater.*;

public class Stack<T> {
	
	private static class Node<T> {
		final T element;
		Node<T> lowerNode = null;

		public Node(T element) {
			this.element = element;
		}
	}

	private volatile Node<T> top = null;
	
	@SuppressWarnings("unchecked")
	private static AtomicReferenceFieldUpdater<Stack, Node> topUpdater = newUpdater(
	Stack.class, Node.class, "top");

	public void push(T element) {
		Node<T> newTop = new Node<T>(element);
		Node<T> oldTop;
		do {
			oldTop = top;
			newTop.lowerNode = oldTop;
		} while (!topUpdater.compareAndSet(this, oldTop, newTop));
	}

	public T pop() {
		Node<T> oldTop;
		Node<T> newTop;
		do {
			oldTop = top;
			if (null == oldTop)
				throw new EmptyStackException();
			newTop = oldTop.lowerNode;
		} while (!topUpdater.compareAndSet(this, oldTop, newTop));
		return oldTop.element;
	}
	
	public boolean isEmpty() {
		return  null == top;
	}
	
}
