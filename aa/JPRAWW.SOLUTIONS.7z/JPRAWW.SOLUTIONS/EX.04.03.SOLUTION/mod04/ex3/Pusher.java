package mod04.ex3;

import java.util.Random;

public class Pusher implements Runnable {
	private Stack<String> stack;
	private int repeats;

	public Pusher(Stack<String> stack, int repeats) {
		this.stack = stack;
		this.repeats = repeats;
	}

	@Override
	public void run() {
		Random r = new Random();
		System.out.println("'" + Thread.currentThread().getName()
				+ "' is going to put " + repeats + " elements on the stack");
		for (int i = 0; i < repeats; i++) {
			stack.push("a");
			try {
				Thread.sleep(r.nextInt(10));
			} catch (InterruptedException e) {
				return;
			}
		}
	}
}