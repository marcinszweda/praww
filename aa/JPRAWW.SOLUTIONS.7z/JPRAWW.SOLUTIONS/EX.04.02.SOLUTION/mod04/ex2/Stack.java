package mod04.ex2;

import java.util.EmptyStackException;
import java.util.concurrent.atomic.AtomicReference;

public class Stack<T> {

	private static class Node<T> {
		final T element;
		Node<T> lowerNode = null;

		public Node(T element) {
			this.element = element;
		}
	}

	private final AtomicReference<Node<T>> topRef = new AtomicReference<Node<T>>(null);

	public void push(T element) {
		Node<T> newTop = new Node<T>(element);
		Node<T> oldTop;
		do {
			oldTop = topRef.get();
			newTop.lowerNode = oldTop;
		} while (!topRef.compareAndSet(oldTop, newTop));
	}

	public T pop() {
		Node<T> oldTop;
		Node<T> newTop;
		do {
			oldTop = topRef.get();
			if (null == oldTop)
				throw new EmptyStackException();
			newTop = oldTop.lowerNode;
		} while (!topRef.compareAndSet(oldTop, newTop));
		return oldTop.element;
	}

	public boolean isEmpty() {
		return null == topRef.get();
	}

}
