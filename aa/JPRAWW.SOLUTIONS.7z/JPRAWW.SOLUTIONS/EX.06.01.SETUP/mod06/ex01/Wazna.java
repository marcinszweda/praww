package mod06.ex01;

public class Wazna {
	public static int dana = 1;
}