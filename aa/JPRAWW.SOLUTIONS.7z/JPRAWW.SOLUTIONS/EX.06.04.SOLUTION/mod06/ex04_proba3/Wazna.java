package mod06.ex04_proba3;

public class Wazna {
	public static int dana = 1;
}