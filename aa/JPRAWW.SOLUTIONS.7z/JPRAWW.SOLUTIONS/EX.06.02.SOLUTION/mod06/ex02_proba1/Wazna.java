package mod06.ex02_proba1;

public class Wazna {
	public static int dana = 1;
}