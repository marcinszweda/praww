package mod06.ex02_proba1;

public final class Igloo {

	public final static int MALY = 1;
	public final static int DUZY = 2;
	public volatile static int czyjaKolej = MALY;

}