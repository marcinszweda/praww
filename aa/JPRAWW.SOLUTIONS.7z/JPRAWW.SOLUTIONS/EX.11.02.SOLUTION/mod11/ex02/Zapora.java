package mod11.ex02;

public class Zapora {
	public static final Semafor szlaban = new Semafor(1);
}
