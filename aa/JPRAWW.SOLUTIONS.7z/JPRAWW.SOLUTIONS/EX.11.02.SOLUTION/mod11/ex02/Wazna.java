package mod11.ex02;

public class Wazna {
	public static int dana = 1;
}