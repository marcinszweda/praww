package mod06.ex06_dekker;

public class Wazna {
	public static int dana = 1;
}