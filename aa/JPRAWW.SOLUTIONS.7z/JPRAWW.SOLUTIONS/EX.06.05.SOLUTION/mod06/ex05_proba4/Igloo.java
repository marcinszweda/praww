package mod06.ex05_proba4;

public final class Igloo {
	
	public final static int WSTEP_WOLNY = 1;
	public final static int ZAKAZ_WSTEPU = 0;
	public static int tablicaMalego = WSTEP_WOLNY;
	public static int tablicaDuzego = WSTEP_WOLNY;

}