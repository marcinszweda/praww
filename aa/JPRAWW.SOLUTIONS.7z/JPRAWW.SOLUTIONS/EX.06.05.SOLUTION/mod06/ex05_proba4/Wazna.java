package mod06.ex05_proba4;

public class Wazna {
	public static int dana = 1;
}