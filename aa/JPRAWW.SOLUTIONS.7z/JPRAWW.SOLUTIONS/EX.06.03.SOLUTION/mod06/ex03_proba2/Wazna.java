package mod06.ex03_proba2;

public class Wazna {
	public static int dana = 1;
}