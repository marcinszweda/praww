package mod07.ex01_eskimosi;

public class Wazna {
	public static int dana = 1;
}