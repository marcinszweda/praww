package mod07.ex01_eskimosi;

import java.util.concurrent.Semaphore;

public class Semafor {
	public static final Semaphore szlaban = new Semaphore(1);
}
