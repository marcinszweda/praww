package mod13;

import java.math.BigInteger;

public class Recursion {

	public static BigInteger calculate(BigInteger[] coeff, BigInteger x) {
		return recursion(coeff, x, 0);
	}

	private static BigInteger recursion(BigInteger[] coeff, BigInteger x, int i) {
		int n = coeff.length - 1;
		if (i == n)
			return coeff[n];
		return recursion(coeff, x, i + 1).multiply(x).add(coeff[i]);
	}
}
