package mod13;

import java.math.BigInteger;
import java.util.concurrent.CountDownLatch;

public class Threads {
	private static CountDownLatch barrier;
	private static BigInteger[] partResults;

	static class Worker implements Runnable {
		private BigInteger[] coeff;
		private BigInteger x;
		private int nParts;
		private int i;

		public Worker(BigInteger[] coeff, BigInteger x, int nParts, int i) {
			this.coeff = coeff;
			this.x = x;
			this.nParts = nParts;
			this.i = i;
		}

		@Override
		public void run() {
			partResults[i] = Horner.calculate(coeff, x, nParts, i);
			barrier.countDown();
		}
	}

	public static BigInteger calculate(BigInteger[] coeff, BigInteger x,
			int nParts) {
		partResults = new BigInteger[nParts];
		BigInteger arg = x;
		for (int i = 1; i < nParts; i++) {
			arg = arg.multiply(x);
		}
		barrier = new CountDownLatch(nParts);
		for (int i = 0; i < nParts; i++) {
			new Thread(new Worker(coeff, arg, nParts, i)).start();
		}
		try {
			barrier.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Horner.calculate(partResults, x, 1, 0);
	}
}
