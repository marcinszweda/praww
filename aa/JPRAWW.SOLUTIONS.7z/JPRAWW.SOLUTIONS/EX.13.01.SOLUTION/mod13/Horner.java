package mod13;

import java.math.BigInteger;

public class Horner {

	public static BigInteger calculate(BigInteger[] coeff, BigInteger x,
			int step, int offset) {
		int n = coeff.length;
		BigInteger result = BigInteger.ZERO;
		int idx = ((n - 1) / step) * step + offset;
		if (idx >= n) {
			result = BigInteger.ZERO;
		} else {
			result = coeff[idx];
		}
		for (int i = idx - step; i >= 0; i -= step) {
			result = result.multiply(x).add(coeff[i]);
		}
		return result;
	}
}
