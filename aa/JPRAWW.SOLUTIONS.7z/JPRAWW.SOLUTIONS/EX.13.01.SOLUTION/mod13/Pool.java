package mod13;

import java.math.BigInteger;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Pool {
	private static ExecutorService pool;

	static class Worker implements Callable<BigInteger> {
		private BigInteger[] coeff;
		private BigInteger x;
		private int nParts;
		private int i;

		public Worker(BigInteger[] coeff, BigInteger x, int nParts, int i) {
			this.coeff = coeff;
			this.x = x;
			this.nParts = nParts;
			this.i = i;
		}

		@Override
		public BigInteger call() throws Exception {
			return Horner.calculate(coeff, x, nParts, i);
		}
	}

	public static BigInteger calculate(BigInteger[] coeff, BigInteger x, int n) {
		pool = Executors.newFixedThreadPool(n);
		BigInteger[] partResults = new BigInteger[n];
		Future<BigInteger> [] results = new Future[n];
		BigInteger arg = x;
		for (int i = 1; i < n; i++) {
			arg = arg.multiply(x);
		}
		for (int i = 0; i < n; i++) {
			Worker task = new Worker(coeff, arg, n, i);
			results[i] = pool.submit(task);
		}
		for (int i=0;i<n;i++) {
			try {
				partResults[i]=results[i].get();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}
		BigInteger result = Horner.calculate(partResults, x, 1, 0);
		pool.shutdown();
		return result;
	}
}
