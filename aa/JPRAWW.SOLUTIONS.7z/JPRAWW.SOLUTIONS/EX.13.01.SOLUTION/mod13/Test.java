package mod13;

import java.math.BigInteger;

// to increase stack size use -Xss JVM option, eg. -Xss1024k

public class Test {

	public static void main(String[] args) {
		BigInteger x = BigInteger.valueOf(2);
		final int N = 15000;
		BigInteger[] coeff = new BigInteger[N];
		for (int i = 0; i < N; i++) {
			coeff[i] = BigInteger.valueOf(i + 1);
		}
		long start, stop;
		BigInteger r;

		start = System.nanoTime();
		r = Trivial.calculate(coeff, x);
		stop = System.nanoTime();
		// System.out.println(r.toString());
		System.out.println("  trivial= " + (stop - start)/1000000 + " ms");

		start = System.nanoTime();
		r = Horner.calculate(coeff, x, 1, 0);
		stop = System.nanoTime();
		// System.out.println(r.toString());
		System.out.println("   horner= " + (stop - start)/1000000 + " ms");

		start = System.nanoTime();
		r = Recursion.calculate(coeff, x);
		stop = System.nanoTime();
		// System.out.println(r.toString());
		System.out.println("recursion= " + (stop - start)/1000000 + " ms");

		start = System.nanoTime();
		r = Threads.calculate(coeff, x, 3);
		stop = System.nanoTime();
		// System.out.println(r.toString());
		System.out.println("  threads= " + (stop - start)/1000000 + " ms");

		start = System.nanoTime();
		r = Pool.calculate(coeff, x, 3);
		stop = System.nanoTime();
		// System.out.println(r.toString());
		System.out.println("     pool= " + (stop - start)/1000000 + " ms");
	}
}
