package mod13;

import java.math.BigInteger;

public class Trivial {

	public static BigInteger calculate(BigInteger[] coeff, BigInteger x) {
		BigInteger result = coeff[0];
		BigInteger powerX = BigInteger.ONE;
		for (int i = 1; i < coeff.length; i++) {
			powerX = powerX.multiply(x);
			result = result.add(coeff[i].multiply(powerX));
		}
		return result;
	}
}
